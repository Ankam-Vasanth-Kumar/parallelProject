package com.capgemini.bank.exception;

public class BankApplicationException extends Exception {

	public BankApplicationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankApplicationException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BankApplicationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BankApplicationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BankApplicationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
}
