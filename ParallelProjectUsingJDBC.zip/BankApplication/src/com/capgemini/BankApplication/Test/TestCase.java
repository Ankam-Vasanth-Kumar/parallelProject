package com.capgemini.BankApplication.Test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.service.BankService;
import com.capgemini.BankApplication.service.BankServiceImpl;

public class TestCase {
	BankService obj=new BankServiceImpl();
	Account account=new Account("Vasanth","1234va","321vds","8885401174",365701311106L,50000,1234567890);
	Account account1=new Account("vasanth","1234va","321vds","8885401174",365701311106L,50000,1234567890);
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testisNameValid() {
		boolean result=obj.isNameValid("Vasanth");
		assertFalse(result);
		boolean result1=obj.isMobileValid("amber");
		assertTrue(result1);
		assertNotEquals(result, result1);
		assertEquals(result, false);
		assertNotNull(result);
		
	}
	@Test
	public void testPasswordValid() {
		boolean result=obj.isPasswordValid("1234va");
		assertFalse(result);
		boolean result1=obj.isPasswordValid("va&*(");
		assertTrue(result1);
		assertNotEquals(result, result1);
		assertEquals(result, false);
		assertNotNull(result);
	}
	@Test
	public void testisAddressValid() {
		boolean result=obj.isAddressValid("242vcxAD");
		assertFalse(result);
		boolean result1=obj.isAddressValid("%^&*(^%");
		assertTrue(result1);
		assertNotEquals(result, result1);
		assertEquals(result, false);
		assertNotNull(result);
	}
	@Test
	public void testaddAccount() {
		boolean result=obj.addAccount(account);
		assertTrue(result);
		
	}
	@Test
	public void testgetUnamePassword() {
		HashMap<String, String> result=obj.getUnamePassword();
		assertNotNull(result);
		assertNotSame(result, 123);
	}
	@Test
	public void testgetAccountDetails() {
		HashMap<Long, Account> resutl=obj.getAccountDetails();
		assertNotNull(resutl);
		assertNotSame(resutl, 1213);
	}


}
