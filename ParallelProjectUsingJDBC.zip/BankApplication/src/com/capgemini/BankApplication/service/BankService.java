package com.capgemini.BankApplication.service;

import java.util.HashMap;

import com.capgemini.BankApplication.bean.Account;
import com.capgemini.BankApplication.bean.Transaction;

public interface BankService {

	boolean isNameValid(String uname);

	boolean isPasswordValid(String password);

	boolean isAddressValid(String address);

	boolean isMobileValid(String mobileNo);

	boolean isAadharValid(long aadhrCardNo);

	boolean addAccount(Account account);

	HashMap<Long, Account> getAccountDetails();

	HashMap<String, String> getUnamePassword();

	void ShowBalance(long accountNo);

	boolean addTransaction(Transaction tran, long bal);
	HashMap<Integer, Transaction> getTransaction();

	boolean transferTo(Transaction tran2, long money);

	void deposite(Transaction tran, long bal);

	void withdraw(Transaction tran1, long amount);

}
